
import java.util.Scanner;

  public class Final
{
	public static void main (String [] args)
	{
		System.out.println("Let's have a drink!");
                System.out.println("Sure let's go!");
                
                /*
                Scanner scan = new Scanner(System.in); 
                System.out.print("Please enter your name: ");
                String name = scan.nextLine();
                System.out.println("Hello " + name);
                scan.close();
*/
                Mainframe myframe = new Mainframe();
                myframe.init();
	}
}

